#include <unistd.h>
#include<stdio.h>
#include<string.h>
#include <fcntl.h>
#include<sys/mman.h>
#include<sys/stat.h>
#include<stdlib.h>
#include <errno.h>
#define BUFFSIZE 4096

int tcpmfile(char* src_file,char*dest_file){

 struct stat src_info;
 struct stat dest_info;
 char* src_file_name;
 char* dest_file_name;
 int fd_src_file;
 int fd_dest_file; 
 void*dest;
 void*src;

/*get the information of the argv[1] and argv[2] 
the argv[2] can be a file that doesn't exist
but the argv[1] must be a file*/
 if(lstat(src_file,&src_info)<0){
 printf("lstat the source file error\n");
 return 1;
 }
 lstat(dest_file,&dest_info);

 /*if(S_ISDIR(src_info.st_mode)){
 printf("The first argument is a directory, but not a file");
 return 1;
 }*/

 /*if the argv[1] and argv[2] point to the same file then exit*/
 if(src_info.st_ino==dest_info.st_ino){
 printf("The src-file and the dest-file are same\n");
 return 1;
 }

  /*open the source file*/
 if ((fd_src_file = open(src_file,O_RDONLY) )< 0) {
  printf("open source file fail\n");
  return 1;
 }

/*Get the source file name from src_file*/
 if(strrchr(src_file,'/')!=NULL){
 src_file_name=strrchr(src_file,'/');
 src_file_name++;
 }
 else{
 src_file_name=strcpy((char*)malloc(sizeof(char)*50),src_file);
 }


 dest_file_name=dest_file;
 if(S_ISDIR(dest_info.st_mode)){
 char*slash="/";
 if(dest_file[strlen(dest_file)-1]!='/')
  strcat(dest_file_name,slash);
 strcat(dest_file_name,src_file_name);
 }




 if((fd_dest_file = open(dest_file_name, O_RDWR|O_CREAT|O_TRUNC,S_IRWXU)) < 0) {
  printf("create dest_file fail\n");
  return 1;
  }

ftruncate(fd_dest_file,src_info.st_size);

/*judge whether the source file's size is zero*/
if(src_info.st_size!=0){

/*map the content of the file form disk to memory*/
 src=mmap(NULL,src_info.st_size,PROT_READ,MAP_SHARED,fd_src_file,0);
 dest=mmap(NULL,src_info.st_size,PROT_READ|PROT_WRITE,MAP_SHARED,fd_dest_file,0);

  if(src==MAP_FAILED||dest==MAP_FAILED){
       printf("Mmap error: %s!\n",strerror(errno));
       exit(1);
    }

/*memory copy*/
 memcpy(dest,src,src_info.st_size);

/*update the file content*/
 if(msync(dest,src_info.st_size,MS_SYNC)==-1){
 printf("msync error");
 munmap(src,src_info.st_size);
 munmap(dest,src_info.st_size);
 return 1;
 }

}



munmap(src,src_info.st_size);
munmap(dest,src_info.st_size);
close(fd_src_file);
close(fd_dest_file);
return 0;
}



int main(int argc,char**argv){
/*if the number of the argument is not 3 or any arguments is empty, 
it doesn't satisfy the "tcp" command's format*/
 if (argc != 3) {
  printf("please input three arguments");
  exit(1);
 }
 char*src_file;
 char*dest_file;
 src_file=argv[1];
 dest_file=argv[2];
/*file copy*/
 if(tcpmfile(src_file,dest_file)!=0){
  printf("copy fail\n");
  exit(1);
 }
 printf("copy successfully\n");
 return 0;

}
