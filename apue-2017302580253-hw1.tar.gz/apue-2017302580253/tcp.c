#include <unistd.h>
#include<stdio.h>
#include<string.h>
#include <fcntl.h>
#include<sys/stat.h>
#include<stdlib.h>
#define BUFFSIZE 4096
int main(int argc, char**argv) {
 char n[BUFFSIZE];
 int read_size;
 int fd_src_file;
 int fd_dest_file;
 char *src_file_name;
 char dest_file_name[50];
 struct stat src_buf;
 struct stat dest_buf;

/*if the number of the argument is not 3 or any arguments is empty, 
it doesn't satisfy the "tcp" command's format*/
 if (argc != 3) {
  printf("error");
  exit(1);
 }

 if(argv[1]==NULL||argv[2]==NULL){
  printf("Please enter two valid filenames or directories!\n");
  exit(1);
 }



/*get the information of the argv[1] and argv[2] 
the argv[2] can be a file that doesn't exist
but the argv[1] must be a file*/
 
 if(lstat(argv[1], &src_buf) < 0) {
  printf("lstat error when manage the source file\n");
  exit(1);
 }
   lstat(argv[2], &dest_buf);

/*if the argv[1] is a directory then exit*/
 if(S_ISDIR(src_buf.st_mode)){
 printf("The first argument is a directory, but not a file");
 exit(1);
 }


/*if the argv[1] and argv[2] point to the same file then exit*/
 if(src_buf.st_ino==dest_buf.st_ino){
printf("The src-file and the dest-file are same\n");
exit(1);
 }


/*Get the source file name from argv[1]*/
 if(strrchr(argv[1],'/')!=NULL){
 src_file_name=strrchr(argv[1],'/');
 src_file_name++;
 }
 else{
 src_file_name=strcpy((char*)malloc(sizeof(char)*50),argv[1]);
 }

 /*open the source file*/
 if ((fd_src_file = open(argv[1],O_RDONLY) )< 0) {//open the source file
  perror("open source file fail");
  exit(1);
 }



 if (S_ISDIR(dest_buf.st_mode)) {     
//judge whether the argv[2] is a directory     
   strcpy(dest_file_name,argv[2]);
 if(argv[2][strlen(argv[2])-1]!='/')
   strcat(dest_file_name,"/");
   strcat(dest_file_name,src_file_name);
   printf("%s",dest_file_name);
//change the directory to dir file name
   if ((fd_dest_file = open(dest_file_name, O_WRONLY | O_CREAT | O_TRUNC, 0700)) < 0) {//S_IRWXU
//create a new file under the directory
  perror("create dest_file fail1");
  exit(1);
  }
}
else{

   if ((fd_dest_file = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0700)) < 0) {//S_IRWXU
//create a new file under the directory
  perror("create dest_file fail");
  exit(1);
 }
 
}

/*read the source and write the destination*/
 while ((read_size = read(fd_src_file, n, BUFFSIZE)) > 0)
  if (write(fd_dest_file, n, read_size) != read_size){
   printf("write error");
   exit(1);
  }
  if (read_size < 0){
   perror("read error");
   exit(1);
}

/*close the file*/
  close(fd_src_file);
  close(fd_dest_file);
  
  return 0;
 
}
