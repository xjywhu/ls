#ifndef LS_H_INCLUDED
#define LS_H_INCLUDED
struct filename{
char*name;
int type;
};


#endif // LS_H_INCLUDED
